import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score

st.set_page_config(page_title="Fraud Detection Dashboard", layout="wide")

st.title("💳 Online Payment Fraud Detection")
st.write("Upload your dataset and detect fraudulent transactions using Machine Learning")

# --- Upload CSV ---
uploaded_file = st.file_uploader("Upload CSV Dataset", type=["csv"])

if uploaded_file is not None:
    # Load dataset
    df = pd.read_csv(uploaded_file)
    
    # ✅ Display dataset shape
    st.write("Dataset Shape:", df.shape)

    # ✅ Display random sample of 10 rows
    st.subheader("Random Sample of Dataset")
    st.dataframe(df.sample(10, replace=True))


    # Drop unnecessary columns
    if "nameOrig" in df.columns:
        df = df.drop(["nameOrig", "nameDest"], axis=1)

    # Encode transaction type
    le = LabelEncoder()
    df["type"] = le.fit_transform(df["type"])

    # Features and Target
    X = df.drop("isFraud", axis=1)
    y = df["isFraud"]

    # Train-test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    
    # ✅ Display training and test set shapes
    st.write("Training set shape:", X_train.shape)
    st.write("Test set shape:", X_test.shape)

    # Train Random Forest
    clf = RandomForestClassifier(n_estimators=100, class_weight="balanced", random_state=42)
    clf.fit(X_train, y_train)

    # Predictions
    y_pred = clf.predict(X_test)
    y_proba = clf.predict_proba(X_test)[:, 1]

    # --- Metrics ---
    st.subheader("Model Performance")

    # Confusion Matrix
    cm = confusion_matrix(y_test, y_pred)
    fig, ax = plt.subplots()
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=["Non-Fraud", "Fraud"], yticklabels=["Non-Fraud", "Fraud"])
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    st.pyplot(fig)

    # Classification Report
    report = classification_report(y_test, y_pred, output_dict=True)
    st.dataframe(pd.DataFrame(report).transpose())

    # ROC-AUC Score
    st.metric("ROC-AUC Score", round(roc_auc_score(y_test, y_proba), 3))

    # --- Fraud vs Non-Fraud Distribution ---
    st.subheader("Fraud vs Non-Fraud Distribution")
    fig2, ax2 = plt.subplots()
    sns.countplot(x=y, palette="Set2")
    st.pyplot(fig2)

    # --- Feature Importance ---
    st.subheader("Feature Importance")
    feat_importance = pd.Series(clf.feature_importances_, index=X.columns)
    feat_importance = feat_importance.sort_values(ascending=False)

    fig3, ax3 = plt.subplots()
    sns.barplot(x=feat_importance.values, y=feat_importance.index)
    st.pyplot(fig3)

    # --- Download Predictions ---
    st.subheader("Download Predictions")
    results = X_test.copy()
    results["Actual"] = y_test.values
    results["Predicted"] = y_pred
    results["Fraud_Probability"] = y_proba

    csv = results.to_csv(index=False).encode("utf-8")
    st.download_button(
        label="Download Predictions as CSV",
        data=csv,
        file_name="fraud_predictions.csv",
        mime="text/csv",
    )
else:
    st.info("👆 Upload a CSV file to start fraud detection")
