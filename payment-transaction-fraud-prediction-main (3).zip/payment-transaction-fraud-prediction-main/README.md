1️⃣ Setting up the environment
import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score


Explanation:

streamlit: For building the interactive web dashboard.

pandas: For handling tabular data (CSV files).

numpy: For numerical operations.

matplotlib & seaborn: For plotting graphs and visualizations.

sklearn modules:

train_test_split: Split data into training and testing sets.

LabelEncoder: Convert categorical features (like “PAYMENT”, “TRANSFER”) into numeric codes.

RandomForestClassifier: Machine learning model to detect fraud.

classification_report, confusion_matrix, roc_auc_score: Metrics to evaluate model performance.

2️⃣ Loading the dataset
df = pd.read_csv("fraud_sample.csv")


Reads the CSV file into a Pandas DataFrame.

Each row represents a transaction, and columns include:

step: Time step of the transaction

type: Type of transaction (PAYMENT, TRANSFER, CASH_OUT)

amount: Transaction amount

nameOrig: Sender account

oldbalanceOrg / newbalanceOrig: Sender balance before/after transaction

nameDest: Receiver account

oldbalanceDest / newbalanceDest: Receiver balance before/after

isFraud: Target label (1 = fraud, 0 = normal)

isFlaggedFraud: Extra flag (not always used)

3️⃣ Previewing the dataset
st.dataframe(df.sample(min(10, len(df))))


Shows a random sample of 10 rows on the Streamlit dashboard.

Using min(10, len(df)) ensures it works even if the dataset has fewer than 10 rows (avoiding ValueError).

4️⃣ Encoding categorical features
le = LabelEncoder()
df['type'] = le.fit_transform(df['type'])


ML models require numeric inputs.

LabelEncoder converts transaction types to numbers, e.g.:

PAYMENT → 2

TRANSFER → 1

CASH_OUT → 0

5️⃣ Splitting features and target
X = df.drop(['isFraud', 'isFlaggedFraud', 'nameOrig', 'nameDest'], axis=1)
y = df['isFraud']


X → all features used for prediction.

y → target variable (fraud label).

Dropped columns:

nameOrig and nameDest → text identifiers (not useful numerically)

isFlaggedFraud → optional, may leak info about fraud detection

6️⃣ Train/test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.4, stratify=y, random_state=42
)


Splits data into:

X_train, y_train → used to train the model

X_test, y_test → used to evaluate the model

test_size=0.4: 40% of data for testing.

stratify=y: Maintains the same fraud/non-fraud ratio in train and test sets.

random_state=42: Fixes random splitting for reproducibility.

⚠ Important: For very small datasets (<10 rows), stratified split may fail. In that case, use test_size=1 without stratify, or increase dataset size.

7️⃣ Model training
clf = RandomForestClassifier(n_estimators=100, random_state=42)
clf.fit(X_train, y_train)


RandomForestClassifier:

Ensemble of decision trees

Reduces overfitting compared to a single tree

n_estimators=100 → 100 trees in the forest

clf.fit() → trains the model on the training data

8️⃣ Making predictions
y_pred = clf.predict(X_test)
y_prob = clf.predict_proba(X_test)[:,1]


y_pred: Model’s predicted labels (fraud or not).

y_prob: Model’s predicted probability of being fraud.

9️⃣ Evaluating performance
st.write("Confusion Matrix")
st.write(confusion_matrix(y_test, y_pred))

st.write("Classification Report")
st.write(classification_report(y_test, y_pred))

st.write("ROC AUC Score:", roc_auc_score(y_test, y_prob))


Confusion Matrix → shows TP, TN, FP, FN counts:

TP → correctly predicted fraud

TN → correctly predicted normal

FP → normal predicted as fraud

FN → fraud predicted as normal

Classification Report → metrics like precision, recall, f1-score

ROC AUC Score → overall model ability to distinguish fraud vs normal
